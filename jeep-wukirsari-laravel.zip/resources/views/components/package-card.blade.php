@props(['pkg', 'showBook' => false, 'index' => 0])

@php
    $img = file_exists(public_path($pkg['image'])) ? $pkg['image'] : 'images/hero.jpeg';
@endphp

<article class="package-card reveal reveal-d{{ min($index, 5) }}"
         data-category="{{ $pkg['category'] }}" data-name="{{ \Illuminate\Support\Str::lower($pkg['name']) }}">
    <a class="package-card__media" href="{{ route('packages.show', $pkg['slug']) }}" tabindex="-1" aria-hidden="true">
        <img src="{{ asset($img) }}" alt="" loading="lazy" width="640" height="480">
        @if($pkg['popular'] ?? false)
            <span class="badge">Paling Populer</span>
        @endif
    </a>
    <div class="package-card__body">
        <h3 class="package-card__title">
            <a href="{{ route('packages.show', $pkg['slug']) }}">{{ $pkg['name'] }}</a>
        </h3>
        @if($showBook)
            <p class="package-card__summary">{{ $pkg['summary'] }}</p>
        @endif
        <ul class="package-card__meta">
            <li><x-icon name="clock" :size="16" /> {{ $pkg['duration'] }}</li>
            <li><x-icon name="users" :size="16" /> {{ $pkg['capacity'] }}</li>
            <li><x-icon name="map-pin" :size="16" /> {{ $pkg['location'] }}</li>
        </ul>
        <div class="package-card__foot">
            <p class="price">Rp {{ number_format($pkg['price'], 0, ',', '.') }} <small>/jeep</small></p>
            <div class="package-card__actions">
                <a class="btn btn--outline" href="{{ route('packages.show', $pkg['slug']) }}">
                    Lihat Detail <x-icon name="arrow-right" :size="16" />
                </a>
                @if($showBook)
                    <button type="button" class="btn btn--primary" data-booking="{{ $pkg['slug'] }}">Booking</button>
                @endif
            </div>
        </div>
    </div>
</article>
