<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Jeep Wisata Wukirsari, Cangkringan, Sleman | Offroad Lereng Merapi')</title>
    <meta name="description" content="@yield('description', 'Paket jeep wisata offroad di Wukirsari, Cangkringan, Sleman, Yogyakarta dengan driver berpengalaman. Booking mudah lewat WhatsApp.')">
    <link rel="canonical" href="{{ url()->current() }}">

    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:title" content="@yield('title', 'Jeep Wisata Wukirsari, Cangkringan, Sleman')">
    <meta property="og:description" content="@yield('description', 'Paket jeep wisata offroad di lereng Merapi, Wukirsari, Cangkringan, Sleman.')">
    <meta property="og:image" content="{{ asset('images/hero.jpeg') }}">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@600&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('css/tokens.css') }}">
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
    <script>document.documentElement.classList.add('js');</script>
    @stack('head')
</head>
<body class="@yield('body_class')">

@php
    $brand   = config('jeep.brand');
    $contact = config('jeep.contact');
    $social  = array_filter(config('jeep.social'));
    $wa      = preg_replace('/\D/', '', (string) ($contact['whatsapp'] ?? ''));
    $hasGallery = ! empty(glob(public_path('images/gallery/*.*')));
@endphp

<a class="skip-link" href="#main">Lewati ke konten</a>

<header class="site-header">
    <div class="container site-header__inner">
        <a href="{{ route('home') }}" class="brand" aria-label="{{ $brand['name'] }}, beranda">
            <img class="brand__logo" src="{{ asset('images/logo.png') }}" alt="" width="44" height="44">
            <span>
                <span class="brand__name">{{ $brand['name'] }}</span>
                <span class="brand__tag">{{ $brand['tagline'] }}</span>
            </span>
        </a>

        <nav id="site-nav" class="nav" aria-label="Navigasi utama">
            <ul class="nav__list">
                <li><a class="nav__link" href="{{ route('home') }}" @if(request()->routeIs('home')) aria-current="page" @endif>Beranda</a></li>
                <li><a class="nav__link" href="{{ route('packages.index') }}" @if(request()->routeIs('packages.*')) aria-current="page" @endif>Paket Wisata</a></li>
                <li><a class="nav__link" href="{{ route('home') }}#tentang">Tentang Kami</a></li>
                @if($hasGallery)
                    <li><a class="nav__link" href="{{ route('home') }}#galeri">Galeri</a></li>
                @endif
                <li><a class="nav__link" href="#kontak">Kontak</a></li>
            </ul>
            <button type="button" class="btn btn--primary btn--block nav__cta" data-booking>
                <x-icon name="calendar-check" :size="18" /> Booking Sekarang
            </button>
        </nav>

        <div class="site-header__actions">
            <button type="button" class="btn btn--primary header-cta" data-booking>
                <x-icon name="calendar-check" :size="18" /> Booking Sekarang
            </button>
            <button type="button" class="nav-toggle" data-nav-toggle aria-expanded="false" aria-controls="site-nav" aria-label="Buka menu">
                <x-icon name="menu" :size="24" class="icon--open" />
                <x-icon name="x" :size="24" class="icon--close" />
            </button>
        </div>
    </div>
</header>

<main id="main">
    @yield('content')
</main>

<footer class="footer" id="kontak">
    <div class="container">
        <div class="footer__grid">
            <div>
                <p class="footer__brand-name">{{ $brand['name'] }}</p>
                <p class="footer__text">{{ $brand['tagline'] }}. Wisata jeep offroad di lereng Merapi, Wukirsari, Cangkringan, Sleman.</p>
            </div>

            <div>
                <h2 class="footer__title">Navigasi</h2>
                <ul class="footer__list">
                    <li><a href="{{ route('home') }}">Beranda</a></li>
                    <li><a href="{{ route('packages.index') }}">Paket Wisata</a></li>
                    <li><a href="{{ route('home') }}#tentang">Tentang Kami</a></li>
                    @if($hasGallery)<li><a href="{{ route('home') }}#galeri">Galeri</a></li>@endif
                </ul>
            </div>

            <div>
                <h2 class="footer__title">Kontak Kami</h2>
                <ul class="footer__list">
                    @if($wa !== '')
                        <li><x-icon name="phone" :size="16" /><a href="https://wa.me/{{ $wa }}" target="_blank" rel="noopener">+{{ $wa }}</a></li>
                    @endif
                    @if(!empty($contact['email']))
                        <li><x-icon name="mail" :size="16" /><a href="mailto:{{ $contact['email'] }}">{{ $contact['email'] }}</a></li>
                    @endif
                    <li><x-icon name="map-pin" :size="16" /><span>{{ $contact['address'] }}</span></li>
                    <li><x-icon name="clock" :size="16" /><span>Buka setiap hari {{ $contact['hours'] }}</span></li>
                </ul>
            </div>

            <div>
                <h2 class="footer__title">Ikuti Kami</h2>
                @if(count($social))
                    <div class="social">
                        @foreach($social as $network => $url)
                            <a href="{{ $url }}" target="_blank" rel="noopener" aria-label="{{ ucfirst($network) }}">
                                <x-icon :name="$network" :size="20" />
                            </a>
                        @endforeach
                    </div>
                @else
                    <p class="footer__text">Segera hadir.</p>
                @endif
            </div>
        </div>
        <div class="footer__bottom">&copy; {{ date('Y') }} {{ $brand['name'] }}. Hak cipta dilindungi.</div>
    </div>
</footer>

{{-- Dialog booking --}}
<dialog class="dialog" id="booking-dialog" aria-labelledby="booking-title"
        data-open="{{ ($errors->any() || session('booking_error')) ? 'true' : 'false' }}">
    <div class="dialog__body">
        <button type="button" class="dialog__close" data-dialog-close aria-label="Tutup formulir">
            <x-icon name="x" :size="20" />
        </button>
        <div class="dialog__head">
            <h2 class="dialog__title" id="booking-title">Booking {{ $brand['name'] }}</h2>
            <p class="dialog__desc">Isi data berikut. Pesananmu akan dikirim ke WhatsApp admin untuk konfirmasi slot.</p>
        </div>

        @if(session('booking_error'))
            <div class="alert" role="alert"><x-icon name="alert" :size="18" /> {{ session('booking_error') }}</div>
        @endif

        <form class="form" method="POST" action="{{ route('tour.book') }}" novalidate>
            @csrf
            <div class="form__row">
                <div class="field">
                    <label class="field__label" for="booking-name">Nama lengkap</label>
                    <input class="field__control" id="booking-name" name="name" type="text" autocomplete="name"
                           value="{{ old('name') }}" required @error('name') aria-invalid="true" aria-describedby="err-name" @enderror>
                    @error('name')<p class="field__error" id="err-name"><x-icon name="alert" :size="16" /> {{ $message }}</p>@enderror
                </div>
                <div class="field">
                    <label class="field__label" for="booking-phone">Nomor WhatsApp</label>
                    <input class="field__control" id="booking-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel"
                           placeholder="08xxxxxxxxxx" value="{{ old('phone') }}" required @error('phone') aria-invalid="true" aria-describedby="err-phone" @enderror>
                    @error('phone')<p class="field__error" id="err-phone"><x-icon name="alert" :size="16" /> {{ $message }}</p>@enderror
                </div>
            </div>

            <div class="field">
                <label class="field__label" for="booking-package">Paket wisata</label>
                <select class="field__control" id="booking-package" name="package" required @error('package') aria-invalid="true" aria-describedby="err-package" @enderror>
                    @foreach(config('jeep.packages') as $p)
                        <option value="{{ $p['slug'] }}" data-session="{{ $p['default_session'] }}" @selected(old('package') === $p['slug'])>
                            {{ $p['name'] }} - Rp {{ number_format($p['price'], 0, ',', '.') }} / jeep ({{ $p['duration'] }})
                        </option>
                    @endforeach
                </select>
                @error('package')<p class="field__error" id="err-package"><x-icon name="alert" :size="16" /> {{ $message }}</p>@enderror
            </div>

            <div class="form__row">
                <div class="field">
                    <label class="field__label" for="booking-date">Tanggal keberangkatan</label>
                    <input class="field__control" id="booking-date" name="date" type="date" min="{{ now()->toDateString() }}"
                           value="{{ old('date') }}" required @error('date') aria-invalid="true" aria-describedby="err-date" @enderror>
                    @error('date')<p class="field__error" id="err-date"><x-icon name="alert" :size="16" /> {{ $message }}</p>@enderror
                </div>
                <div class="field">
                    <label class="field__label" for="booking-session">Sesi</label>
                    <select class="field__control" id="booking-session" name="session" required>
                        @foreach(config('jeep.sessions') as $key => $label)
                            <option value="{{ $key }}" @selected(old('session') === $key)>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="field">
                <label class="field__label" for="booking-jeeps">Jumlah jeep (maks. 4 orang per jeep)</label>
                <select class="field__control" id="booking-jeeps" name="jeeps" required>
                    @foreach([1, 2, 3, 4, 5] as $n)
                        <option value="{{ $n }}" @selected((int) old('jeeps', 1) === $n)>{{ $n }} jeep ({{ ($n - 1) * 4 + 1 }} - {{ $n * 4 }} orang)</option>
                    @endforeach
                    <option value="6" @selected((int) old('jeeps') === 6)>Lebih dari 5 jeep</option>
                </select>
            </div>

            <div class="field">
                <label class="field__label" for="booking-notes">Catatan (opsional)</label>
                <textarea class="field__control" id="booking-notes" name="notes" rows="2" maxlength="300">{{ old('notes') }}</textarea>
            </div>

            <button type="submit" class="btn btn--primary btn--block">
                Lanjut ke WhatsApp <x-icon name="arrow-right" :size="18" />
            </button>
        </form>
    </div>
</dialog>

<dialog class="dialog dialog--media" id="lightbox" aria-label="Pratinjau foto">
    <img src="" alt="">
</dialog>

<script src="{{ asset('js/site.js') }}" defer></script>
</body>
</html>
