@extends('layouts.app')

@section('title', 'Jeep Wisata Wukirsari, Cangkringan, Sleman | Offroad Lereng Merapi')
@section('description', 'Paket jeep wisata offroad di Wukirsari, Cangkringan, Sleman, Yogyakarta: Short, Medium, Long, dan Sunrise Trip dengan driver berpengalaman. Booking mudah lewat WhatsApp.')

@section('content')
@php
    $features = [
        ['car-front',   'Jeep 4x4',            'Siap di segala medan'],
        ['user-check',  'Driver Berpengalaman', 'Pemandu profesional'],
        ['shield-check','Fasilitas Lengkap',    'Aman dan nyaman'],
        ['map-pin',     'Lokasi Strategis',     'Dekat Gunung Merapi'],
    ];
    $why = [
        ['circle-check',   'Harga Transparan',  'Tanpa biaya tersembunyi'],
        ['message-circle', 'Pelayanan Ramah',   'Konfirmasi via WhatsApp'],
        ['route',          'Jalur Aman',        'Dipilih sesuai kondisi'],
        ['star',           'Pengalaman Terbaik', 'Perjalanan yang berkesan'],
    ];
    $testimonials = config('jeep.testimonials');
@endphp

<section class="hero">
    <div class="hero__media">
        <img src="{{ asset('images/hero.jpeg') }}" alt="Jeep 4x4 di lereng Gunung Merapi" fetchpriority="high">
    </div>
    <div class="container hero__content">
        <p class="script hero__eyebrow">Petualangan di Lereng Merapi</p>
        <h1 class="hero__title">Jelajahi Keindahan Alam Merapi Bersama {{ config('jeep.brand.name') }}</h1>
        <p class="hero__lead">Rasakan petualangan seru menyusuri jalur offroad, menikmati panorama Merapi, dan menciptakan cerita perjalanan yang tak terlupakan.</p>
        <div class="hero__actions">
            <button type="button" class="btn btn--primary" data-booking>
                Booking Sekarang <x-icon name="arrow-right" :size="18" />
            </button>
            <a class="btn btn--ghost" href="{{ route('packages.index') }}">Jelajahi Paket</a>
        </div>
        <p class="hero__loc"><x-icon name="map-pin" :size="16" /> Wukirsari, Cangkringan, Sleman, Yogyakarta</p>
    </div>
</section>

<section class="strip" aria-label="Keunggulan">
    <div class="container">
        <ul class="strip__list">
            @foreach($features as [$icon, $title, $desc])
                <li class="strip__item">
                    <span class="icon-circle"><x-icon :name="$icon" :size="24" /></span>
                    <span>
                        <span class="strip__title">{{ $title }}</span>
                        <span class="strip__desc">{{ $desc }}</span>
                    </span>
                </li>
            @endforeach
        </ul>
    </div>
</section>

<section class="section" id="paket">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow">Paket Wisata</span>
                <h2 class="section-title">Pilihan Paket Wisata</h2>
                <p class="section-desc">Pilih rute yang sesuai dengan waktu dan seleramu. Harga per jeep, maksimal 4 orang.</p>
            </div>
            <a class="link-arrow" href="{{ route('packages.index') }}">Lihat Semua <x-icon name="arrow-right" :size="16" /></a>
        </div>
        <div class="packages-grid packages-grid--4">
            @foreach($packages as $i => $pkg)
                <x-package-card :pkg="$pkg" :index="$i" :show-book="true" />
            @endforeach
        </div>
    </div>
</section>

<section class="section section--flush-top" id="tentang">
    <div class="container">
        <div class="why reveal">
            <div>
                <p class="script">Mengapa Memilih</p>
                <h2 class="why__title">{{ config('jeep.brand.name') }}?</h2>
                <p class="why__text">Kami berkomitmen memberikan pengalaman terbaik untuk setiap perjalanan. Dengan pelayanan profesional, fasilitas lengkap, dan rute yang aman, liburanmu akan menjadi lebih berkesan.</p>
            </div>
            <ul class="why__list">
                @foreach($why as [$icon, $title, $desc])
                    <li class="why__item">
                        <span class="icon-circle"><x-icon :name="$icon" :size="24" /></span>
                        <strong>{{ $title }}</strong>
                        <span>{{ $desc }}</span>
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
</section>

@if($gallery->isNotEmpty())
<section class="section section--flush-top" id="galeri">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow">Galeri</span>
                <h2 class="section-title">Momen Indah Bersama Kami</h2>
            </div>
        </div>
        <div class="gallery">
            @foreach($gallery as $path)
                <button type="button" class="gallery__item" data-lightbox="{{ asset($path) }}" data-alt="Foto perjalanan jeep {{ $loop->iteration }}">
                    <img src="{{ asset($path) }}" alt="Foto perjalanan jeep {{ $loop->iteration }}" loading="lazy">
                </button>
            @endforeach
        </div>
    </div>
</section>
@endif

@if(count($testimonials))
<section class="section section--flush-top">
    <div class="container">
        <div class="section-head">
            <div>
                <span class="eyebrow">Testimoni</span>
                <h2 class="section-title">Apa Kata Mereka?</h2>
            </div>
        </div>
        <div class="testi-grid">
            @foreach($testimonials as $t)
                <figure class="testi reveal">
                    <div class="testi__stars" role="img" aria-label="Rating {{ $t['rating'] }} dari 5">
                        @for($s = 0; $s < $t['rating']; $s++)<x-icon name="star" :size="16" class="icon--solid" />@endfor
                    </div>
                    <blockquote class="testi__text">{{ $t['text'] }}</blockquote>
                    <figcaption class="testi__who"><strong>{{ $t['name'] }}</strong>, {{ $t['city'] }}</figcaption>
                </figure>
            @endforeach
        </div>
    </div>
</section>
@endif
@endsection
