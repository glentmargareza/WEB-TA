@extends('layouts.app')

@section('title', 'Paket Wisata Jeep Wukirsari | Short, Medium, Long, dan Sunrise Trip')
@section('description', 'Pilih paket jeep wisata di Wukirsari, Cangkringan, Sleman: Short Trip, Medium Trip, Long Trip, dan Sunrise Trip. Harga per jeep, maksimal 4 orang.')

@section('content')
<section class="hero hero--page">
    <div class="hero__media">
        <img src="{{ asset('images/hero.jpeg') }}" alt="" fetchpriority="high">
    </div>
    <div class="container hero__content">
        <h1 class="hero__title">Paket Wisata</h1>
        <p class="hero__lead">Pilih paket perjalanan yang sesuai dengan keinginanmu.</p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="filter" role="search">
            <div class="filter__chips" role="group" aria-label="Filter paket">
                <button type="button" class="chip" data-filter="all" aria-pressed="true">Semua</button>
                @foreach($packages as $pkg)
                    <button type="button" class="chip" data-filter="{{ $pkg['category'] }}" aria-pressed="false">{{ $pkg['name'] }}</button>
                @endforeach
            </div>
            <label class="search">
                <x-icon name="search" :size="18" />
                <span class="sr-only">Cari paket wisata</span>
                <input type="search" data-search placeholder="Cari paket wisata..." autocomplete="off">
            </label>
        </div>

        <div class="section-head">
            <h2 class="section-title">Pilihan Paket</h2>
        </div>

        <div class="packages-grid packages-grid--4" data-package-grid>
            @foreach($packages as $i => $pkg)
                <x-package-card :pkg="$pkg" :index="$i" />
            @endforeach
        </div>

        <div class="empty" data-empty hidden>
            <x-icon name="search" :size="32" />
            <p>Paket tidak ditemukan. Coba kata kunci lain.</p>
            <button type="button" class="btn btn--outline" data-filter="all" data-reset-search>Tampilkan semua paket</button>
        </div>
    </div>
</section>
@endsection
