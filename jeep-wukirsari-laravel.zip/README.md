# Paket rombak tampilan Jeep Wukirsari (Laravel)

Mengikuti `DESIGN_SYSTEM.md`: tema terang (krem + hijau), 3 halaman, tanpa emoji, ikon SVG, 2 font.
Data: Wukirsari, Cangkringan, Sleman. Paket: Short 350rb, Medium 450rb, Long 550rb, Sunrise 500rb (per jeep).

## Isi

| File | Fungsi |
|---|---|
| `routes/web.php` | 4 route: `home`, `packages.index`, `packages.show`, `tour.book` |
| `app/Http/Controllers/TourController.php` | Halaman + booking (validasi lalu redirect ke WhatsApp) |
| `config/jeep.php` | SEMUA konten: paket, harga, fasilitas, sesi, kontak, sosial, testimoni |
| `resources/views/layouts/app.blade.php` | Header, footer, dialog booking, lightbox |
| `resources/views/home.blade.php` | Beranda |
| `resources/views/packages/index.blade.php` | Paket Wisata (filter + cari) |
| `resources/views/packages/show.blade.php` | Detail paket (galeri, fasilitas, tab, CTA) |
| `resources/views/components/icon.blade.php` | Ikon SVG: `<x-icon name="clock" />` |
| `resources/views/components/package-card.blade.php` | Kartu paket (dipakai Beranda dan Paket Wisata) |
| `public/css/tokens.css` | Token desain |
| `public/css/site.css` | Seluruh gaya (mobile-first) |
| `public/js/site.js` | Nav, dialog, filter, tab, galeri, reveal |

## Cara pasang

1. **Backup dulu** (commit git atau salin folder). File berikut akan tertimpa: `routes/web.php`, `TourController.php`, `layouts/app.blade.php`.
   Jika `TourController@book` lama menyimpan data ke database, gabungkan logikanya secara manual.
2. Salin semua file ke proyek sesuai path.
3. Tambahkan ke `.env` (isi data ASLI):
   ```
   JEEP_WHATSAPP=62812xxxxxxxx
   JEEP_EMAIL=
   JEEP_ADDRESS="Wukirsari, Cangkringan, Sleman, D.I. Yogyakarta"
   JEEP_HOURS="07.00 - 17.00 WIB"
   JEEP_INSTAGRAM=
   JEEP_FACEBOOK=
   JEEP_YOUTUBE=
   ```
   Kosongkan yang belum ada; bagian itu otomatis tidak tampil. Tanpa `JEEP_WHATSAPP`, booking menampilkan pesan error.
4. Jalankan: `php artisan config:clear && php artisan route:clear && php artisan view:clear`
5. Pastikan ada `public/images/hero.jpeg` dan `public/images/logo.png` (sudah dipakai kodemu).
6. Opsional: foto paket di `public/images/packages/<slug>.jpg` (`short-trip`, `medium-trip`, `long-trip`, `sunrise-trip`)
   dan foto galeri di `public/images/gallery/` (bagian Galeri tampil otomatis jika ada file).
7. Hapus file lama yang tidak dipakai lagi: `resources/views/index.blade.php`, `welcome.blade.php`,
   `public/css/style.css`, `public/js/main.js`, `resources/css/app.css` (dan impor Vite jika tidak dipakai).

## Yang masih perlu kamu isi / cek (aku tidak bisa menebaknya)

- Nomor WhatsApp, email, alamat lengkap, jam buka, tautan sosial (lewat `.env`).
- **Itinerary** tiap paket di `config/jeep.php` hanya contoh umum. Ganti dengan rute asli.
- **Durasi Sunrise Trip** kutulis 3 - 4 jam (dari desain), sedangkan kode lama menulis jam berangkat 04.30 WIB. Sesuaikan.
- **Testimoni** kosong (bagian disembunyikan) sampai ada testimoni asli.
- **Ketentuan** (pembatalan, cuaca, batas usia) belum ditulis karena aku tidak tahu kebijakanmu; tambahkan di `packages/show.blade.php`.
- Nama titik wisata lama (Watu Goyang, Bukit Pengilon, Makam Imogiri) sengaja tidak dipakai karena terkait Imogiri, bukan Cangkringan.

## Catatan
- Kode ini belum dijalankan di Laravel sungguhan (lingkunganku tidak punya PHP). JS sudah dicek sintaksnya, CSS seimbang, dan arahan Blade sudah dicek seimbang. Jalankan `php artisan route:list` dan buka 3 halaman untuk memastikan.
- Tidak memakai Vite/Tailwind. CSS/JS dimuat lewat `asset()`.
