/* Jeep Wukirsari - interaksi situs. Tanpa dependensi. */
(() => {
  'use strict';

  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  /* ---------- Header: bayangan saat scroll ---------- */
  const header = $('.site-header');
  const onScroll = () => header && header.classList.toggle('is-scrolled', window.scrollY > 8);
  onScroll();
  addEventListener('scroll', onScroll, { passive: true });

  /* ---------- Navigasi mobile ---------- */
  const toggle = $('[data-nav-toggle]');
  const nav = $('#site-nav');
  if (toggle && nav) {
    const setNav = (open) => {
      nav.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
    };
    toggle.addEventListener('click', () => setNav(!nav.classList.contains('is-open')));
    nav.addEventListener('click', (e) => { if (e.target.closest('a, [data-booking]')) setNav(false); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setNav(false); });
    document.addEventListener('click', (e) => {
      if (!nav.classList.contains('is-open')) return;
      if (!nav.contains(e.target) && !toggle.contains(e.target)) setNav(false);
    });
  }

  /* ---------- Dialog booking ---------- */
  const dialog = $('#booking-dialog');
  if (dialog) {
    const pkgSelect = $('#booking-package');
    const sessionSelect = $('#booking-session');
    let lastTrigger = null;

    const syncSession = () => {
      const opt = pkgSelect && pkgSelect.selectedOptions[0];
      if (opt && opt.dataset.session && sessionSelect) sessionSelect.value = opt.dataset.session;
    };
    if (pkgSelect) pkgSelect.addEventListener('change', syncSession);

    const openBooking = (slug, trigger) => {
      lastTrigger = trigger || null;
      if (slug && pkgSelect) {
        pkgSelect.value = slug;
        syncSession();
      }
      if (!dialog.open) dialog.showModal();
    };

    document.addEventListener('click', (e) => {
      const t = e.target.closest('[data-booking]');
      if (!t) return;
      e.preventDefault();
      openBooking(t.dataset.booking, t);
    });
    $$('[data-dialog-close]', dialog).forEach((b) => b.addEventListener('click', () => dialog.close()));
    dialog.addEventListener('click', (e) => { if (e.target === dialog) dialog.close(); });
    dialog.addEventListener('close', () => { if (lastTrigger) lastTrigger.focus(); });

    const form = $('form', dialog);
    const submitBtn = form && $('[type="submit"]', form);
    if (form && submitBtn) {
      form.addEventListener('submit', () => {
        submitBtn.classList.add('is-loading');
        submitBtn.setAttribute('aria-busy', 'true');
      });
      addEventListener('pageshow', () => {
        submitBtn.classList.remove('is-loading');
        submitBtn.removeAttribute('aria-busy');
      });
    }

    if (dialog.dataset.open === 'true') dialog.showModal();
  }

  /* ---------- Filter + cari paket ---------- */
  const grid = $('[data-package-grid]');
  if (grid) {
    const chips = $$('.chip[data-filter]');
    const search = $('[data-search]');
    const empty = $('[data-empty]');
    let category = 'all';
    let query = '';

    const apply = () => {
      let visible = 0;
      $$('[data-category]', grid).forEach((card) => {
        const show = (category === 'all' || card.dataset.category === category)
                  && (!query || (card.dataset.name || '').includes(query));
        card.hidden = !show;
        if (show) visible += 1;
      });
      if (empty) empty.hidden = visible !== 0;
      chips.forEach((c) => c.setAttribute('aria-pressed', String(c.dataset.filter === category)));
    };

    $$('[data-filter]').forEach((el) => el.addEventListener('click', () => {
      category = el.dataset.filter;
      if (el.dataset.resetSearch !== undefined && search) { search.value = ''; query = ''; }
      apply();
    }));

    if (search) {
      let timer;
      search.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(() => { query = search.value.trim().toLowerCase(); apply(); }, 250);
      });
    }
  }

  /* ---------- Tab (halaman detail) ---------- */
  $$('[data-tabs]').forEach((root) => {
    const tabs = $$('[role="tab"]', root);
    const panels = tabs.map((t) => document.getElementById(t.getAttribute('aria-controls')));
    const select = (i, focus) => {
      tabs.forEach((t, j) => {
        const on = i === j;
        t.setAttribute('aria-selected', String(on));
        t.tabIndex = on ? 0 : -1;
        if (panels[j]) panels[j].hidden = !on;
      });
      if (focus) tabs[i].focus();
    };
    tabs.forEach((t, i) => {
      t.addEventListener('click', () => select(i));
      t.addEventListener('keydown', (e) => {
        const last = tabs.length - 1;
        if (e.key === 'ArrowRight') { e.preventDefault(); select(i === last ? 0 : i + 1, true); }
        else if (e.key === 'ArrowLeft') { e.preventDefault(); select(i === 0 ? last : i - 1, true); }
        else if (e.key === 'Home') { e.preventDefault(); select(0, true); }
        else if (e.key === 'End') { e.preventDefault(); select(last, true); }
      });
    });
  });

  /* ---------- Galeri detail: ganti gambar utama ---------- */
  const stage = $('[data-stage]');
  if (stage) {
    $$('[data-thumb]').forEach((btn) => btn.addEventListener('click', () => {
      stage.style.opacity = '0';
      setTimeout(() => {
        stage.src = btn.dataset.src;
        stage.alt = btn.dataset.alt || '';
        stage.style.opacity = '1';
      }, 150);
      $$('[data-thumb]').forEach((b) => b.setAttribute('aria-current', String(b === btn)));
    }));
  }

  /* ---------- Lightbox galeri ---------- */
  const lightbox = $('#lightbox');
  if (lightbox) {
    const img = $('img', lightbox);
    $$('[data-lightbox]').forEach((btn) => btn.addEventListener('click', () => {
      img.src = btn.dataset.lightbox;
      img.alt = btn.dataset.alt || '';
      lightbox.showModal();
    }));
    lightbox.addEventListener('click', () => lightbox.close());
  }

  /* ---------- Reveal saat scroll ---------- */
  const items = $$('.reveal');
  if (items.length && 'IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    items.forEach((el) => io.observe(el));
  } else {
    items.forEach((el) => el.classList.add('is-visible'));
  }
})();
