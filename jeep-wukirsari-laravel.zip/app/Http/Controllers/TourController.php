<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Validation\Rule;

class TourController extends Controller
{
    private function catalog()
    {
        return collect(config('jeep.packages'));
    }

    public function index()
    {
        $packages = $this->catalog();

        $gallery = collect(File::glob(public_path('images/gallery/*.{jpg,jpeg,png,webp}'), GLOB_BRACE))
            ->map(fn ($path) => 'images/gallery/' . basename($path))
            ->values();

        return view('home', compact('packages', 'gallery'));
    }

    public function packages()
    {
        return view('packages.index', ['packages' => $this->catalog()]);
    }

    public function show(string $slug)
    {
        $package = $this->catalog()->firstWhere('slug', $slug);
        abort_unless($package, 404);

        return view('packages.show', [
            'package'    => $package,
            'facilities' => config('jeep.facilities'),
        ]);
    }

    public function book(Request $request)
    {
        $data = $request->validate([
            'name'    => ['required', 'string', 'max:80'],
            'phone'   => ['required', 'regex:/^\+?[0-9][0-9\s\-]{7,17}$/'],
            'package' => ['required', Rule::in($this->catalog()->pluck('slug')->all())],
            'date'    => ['required', 'date', 'after_or_equal:today'],
            'session' => ['required', Rule::in(array_keys(config('jeep.sessions')))],
            'jeeps'   => ['required', 'integer', 'between:1,6'],
            'notes'   => ['nullable', 'string', 'max:300'],
        ], [
            'name.required'       => 'Nama lengkap wajib diisi.',
            'phone.required'      => 'Nomor WhatsApp wajib diisi.',
            'phone.regex'         => 'Format nomor WhatsApp tidak valid.',
            'package.required'    => 'Pilih paket wisata.',
            'package.in'          => 'Paket yang dipilih tidak tersedia.',
            'date.required'       => 'Tanggal keberangkatan wajib diisi.',
            'date.after_or_equal' => 'Tanggal tidak boleh sebelum hari ini.',
            'session.required'    => 'Pilih sesi jam.',
            'jeeps.required'      => 'Pilih jumlah jeep.',
        ]);

        $whatsapp = preg_replace('/\D/', '', (string) config('jeep.contact.whatsapp'));
        if ($whatsapp === '') {
            return back()->withInput()->with('booking_error', 'Nomor WhatsApp admin belum diatur. Silakan coba lagi nanti.');
        }

        $package = $this->catalog()->firstWhere('slug', $data['package']);
        $rupiah  = fn (int $n) => 'Rp ' . number_format($n, 0, ',', '.');
        $jeeps   = (int) $data['jeeps'];
        $total   = $jeeps <= 5 ? $rupiah($package['price'] * $jeeps) : 'hubungi admin (lebih dari 5 jeep)';
        $date    = Carbon::parse($data['date'])->locale('id')->translatedFormat('l, j F Y');
        $notes   = trim(preg_replace('/\s+/', ' ', (string) ($data['notes'] ?? '')));
        $brand   = config('jeep.brand.name');

        $lines = [
            "Halo Admin {$brand}, saya ingin booking:",
            "Nama: {$data['name']}",
            "WhatsApp: {$data['phone']}",
            "Paket: {$package['name']} ({$rupiah($package['price'])} / jeep)",
            "Tanggal: {$date}",
            'Sesi: ' . config('jeep.sessions')[$data['session']],
            'Jumlah jeep: ' . ($jeeps > 5 ? 'lebih dari 5' : $jeeps),
            "Estimasi total: {$total}",
        ];
        if ($notes !== '') {
            $lines[] = "Catatan: {$notes}";
        }

        return redirect()->away('https://wa.me/' . $whatsapp . '?text=' . rawurlencode(implode("\n", $lines)));
    }
}
