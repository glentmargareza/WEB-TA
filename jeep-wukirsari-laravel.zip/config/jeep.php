<?php

/*
|--------------------------------------------------------------------------
| Data situs Jeep Wukirsari (satu tempat untuk semua konten)
|--------------------------------------------------------------------------
| Ubah data di sini, jangan di file Blade. Kontak diisi lewat file .env.
*/

return [

    'brand' => [
        'name'    => 'Jeep Wukirsari',
        'tagline' => 'Explore More, Create Memories',
    ],

    'contact' => [
        // Format WhatsApp: 62812xxxxxxxx (tanpa +, spasi, atau tanda hubung)
        'whatsapp' => env('JEEP_WHATSAPP'),
        'email'    => env('JEEP_EMAIL'),
        'address'  => env('JEEP_ADDRESS', 'Wukirsari, Cangkringan, Sleman, D.I. Yogyakarta'),
        'hours'    => env('JEEP_HOURS', '07.00 - 17.00 WIB'),
    ],

    // Kosongkan (null) bila belum ada; ikon hanya tampil jika URL diisi.
    'social' => [
        'instagram' => env('JEEP_INSTAGRAM'),
        'facebook'  => env('JEEP_FACEBOOK'),
        'youtube'   => env('JEEP_YOUTUBE'),
    ],

    'sessions' => [
        'pagi'    => 'Pagi (07.00 - 10.00 WIB)',
        'siang'   => 'Siang (10.00 - 13.00 WIB)',
        'sore'    => 'Sore (14.00 - 17.00 WIB)',
        'sunrise' => 'Sunrise (04.30 WIB)',
    ],

    'facilities' => [
        'Jeep 4x4', 'Driver profesional', 'Air mineral', 'Parkir luas', 'Ruang tunggu',
        'Musholla', 'Toilet', 'BBM', 'Tiket masuk', 'Jasa Raharja', 'Antar jemput',
    ],

    /*
    | image: letakkan foto di public/images/packages/<slug>.jpg
    | (jika file belum ada, otomatis memakai images/hero.jpeg)
    | gallery: opsional, daftar path gambar tambahan untuk halaman detail.
    | itinerary: GANTI dengan rute asli kamu (ini hanya contoh umum).
    */
    'packages' => [
        [
            'slug'            => 'short-trip',
            'name'            => 'Short Trip',
            'category'        => 'short',
            'price'           => 350000,
            'duration'        => '1 - 1,5 jam',
            'capacity'        => 'Maks. 4 orang',
            'location'        => 'Cangkringan, Sleman',
            'image'           => 'images/packages/short-trip.jpg',
            'popular'         => false,
            'default_session' => null,
            'summary'         => 'Rute singkat yang ramah keluarga untuk merasakan sensasi offroad di lereng Merapi.',
            'description'     => 'Pilihan tepat untuk kamu yang punya waktu terbatas atau pertama kali mencoba jeep offroad. Perjalanan singkat bersama driver berpengalaman dengan pemandangan lereng Merapi.',
            'itinerary'       => [
                'Kumpul di basecamp dan briefing keselamatan',
                'Perjalanan offroad bersama driver profesional',
                'Berhenti di titik foto',
                'Kembali ke basecamp',
            ],
        ],
        [
            'slug'            => 'medium-trip',
            'name'            => 'Medium Trip',
            'category'        => 'medium',
            'price'           => 450000,
            'duration'        => '2 - 2,5 jam',
            'capacity'        => 'Maks. 4 orang',
            'location'        => 'Cangkringan, Sleman',
            'image'           => 'images/packages/medium-trip.jpg',
            'popular'         => true,
            'default_session' => null,
            'summary'         => 'Jalur lebih panjang dengan pemandangan Merapi dan pengalaman offroad yang seimbang.',
            'description'     => 'Perpaduan jalur menantang dan waktu santai untuk menikmati pemandangan. Cocok untuk keluarga, teman, maupun rombongan kecil.',
            'itinerary'       => [
                'Kumpul di basecamp dan briefing keselamatan',
                'Perjalanan offroad melewati jalur yang lebih panjang',
                'Berhenti di beberapa titik foto dan istirahat',
                'Kembali ke basecamp',
            ],
        ],
        [
            'slug'            => 'long-trip',
            'name'            => 'Long Trip',
            'category'        => 'long',
            'price'           => 550000,
            'duration'        => '3 - 3,5 jam',
            'capacity'        => 'Maks. 4 orang',
            'location'        => 'Cangkringan, Sleman',
            'image'           => 'images/packages/long-trip.jpg',
            'popular'         => false,
            'default_session' => null,
            'summary'         => 'Full track untuk kamu yang ingin pengalaman offroad paling lengkap dan menantang.',
            'description'     => 'Rute terpanjang dengan medan paling bervariasi. Pilihan terbaik bagi pencari adrenalin yang ingin menjelajah lebih jauh.',
            'itinerary'       => [
                'Kumpul di basecamp dan briefing keselamatan',
                'Perjalanan offroad full track',
                'Berhenti di titik foto dan istirahat',
                'Kembali ke basecamp',
            ],
        ],
        [
            'slug'            => 'sunrise-trip',
            'name'            => 'Sunrise Trip',
            'category'        => 'sunrise',
            'price'           => 500000,
            'duration'        => '3 - 4 jam',
            'capacity'        => 'Maks. 4 orang',
            'location'        => 'Cangkringan, Sleman',
            'image'           => 'images/packages/sunrise-trip.jpg',
            'popular'         => false,
            'default_session' => 'sunrise',
            'summary'         => 'Saksikan matahari terbit di atas Merapi dengan suasana pagi yang sejuk dan menenangkan.',
            'description'     => 'Berangkat dini hari (04.30 WIB) untuk menyambut matahari terbit dari titik terbaik, lalu lanjut menyusuri jalur offroad.',
            'itinerary'       => [
                'Kumpul di basecamp pukul 04.30 WIB dan briefing keselamatan',
                'Perjalanan menuju titik sunrise',
                'Menikmati matahari terbit dan sesi foto',
                'Lanjut jalur offroad dan kembali ke basecamp',
            ],
        ],
    ],

    // Kosongkan sampai ada testimoni asli. Format:
    // ['name' => 'Nama', 'city' => 'Kota', 'text' => 'Isi testimoni', 'rating' => 5]
    'testimonials' => [],
];
